-- Adminer 4.8.1 MySQL 5.7.24 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `admin` (`id`, `username`, `password`, `name`) VALUES
(1,	'admin',	'123456',	'Habibah Dian');

DROP TABLE IF EXISTS `calisan`;
CREATE TABLE `calisan` (
  `calisan_id` int(22) NOT NULL AUTO_INCREMENT,
  `calisan_ad` varchar(22) NOT NULL,
  `calisan_soyad` varchar(25) NOT NULL,
  `gorev` varchar(255) NOT NULL,
  `calisan_telp` int(55) NOT NULL,
  `restoran_id` int(11) NOT NULL DEFAULT '11',
  PRIMARY KEY (`calisan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `calisan` (`calisan_id`, `calisan_ad`, `calisan_soyad`, `gorev`, `calisan_telp`, `restoran_id`) VALUES
(212,	'sasaa',	'sasasaa',	'kasiyer',	443233332,	11),
(323,	'sdda',	'asasa',	'sef',	3443432,	11),
(2221,	'murat',	'lara',	'garson',	3232232,	11),
(2332,	'cem',	'lass',	'sef',	3222232,	11),
(3223,	'asds',	'özyildiz',	'temizlik',	444434333,	11),
(3234,	'sdsa',	'dsdsa',	'sef',	322242323,	11),
(33232,	'dsdsa',	'sdsds',	'temzilik',	3232323,	11),
(42323,	'sdjaj',	'sa',	'garson',	43242312,	11),
(44333,	'saddsa',	'asfd',	'garson',	455445343,	11),
(343223,	'addasd',	'asdad',	'garson',	3424343,	11),
(433242,	'afsdd',	'dadd',	'garson',	343434324,	11),
(3223132,	'aded',	'sdasda',	'sef',	43233223,	11),
(3223133,	'krisna',	'fefef',	'ewfwef',	234234234,	11),
(3223134,	'disini nama',	'disini soyad',	'sef',	231923,	110),
(3223135,	'Tenetur nobis alias ',	'Amet quibusdam non ',	'Rerum voluptatem do',	24,	110);

DROP TABLE IF EXISTS `restoran`;
CREATE TABLE `restoran` (
  `restoran_id` int(11) NOT NULL AUTO_INCREMENT,
  `restoran_ad` varchar(50) CHARACTER SET latin1 NOT NULL,
  `sehir_id` int(11) NOT NULL,
  PRIMARY KEY (`restoran_id`),
  KEY `sehir_id` (`sehir_id`),
  CONSTRAINT `FK_restoran_sehir` FOREIGN KEY (`sehir_id`) REFERENCES `sehir` (`sehir_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `restoran_ibfk_1` FOREIGN KEY (`sehir_id`) REFERENCES `sehir` (`sehir_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `restoran_ibfk_2` FOREIGN KEY (`sehir_id`) REFERENCES `sehir` (`sehir_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

INSERT INTO `restoran` (`restoran_id`, `restoran_ad`, `sehir_id`) VALUES
(11,	'Sopung35',	12),
(110,	'Sopung',	12),
(111,	'wdawd',	23);

DROP TABLE IF EXISTS `sehir`;
CREATE TABLE `sehir` (
  `sehir_id` int(11) NOT NULL AUTO_INCREMENT,
  `sehir_ad` varchar(50) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`sehir_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

INSERT INTO `sehir` (`sehir_id`, `sehir_ad`) VALUES
(12,	'istanbul 2'),
(23,	'izmir'),
(25,	'pontianak'),
(26,	'jakarta 1');

DROP TABLE IF EXISTS `siparis`;
CREATE TABLE `siparis` (
  `siparis_id` int(11) NOT NULL AUTO_INCREMENT,
  `musteri_ad` varchar(255) NOT NULL DEFAULT 'anon',
  `siparis_toplam` bigint(20) NOT NULL DEFAULT '1',
  `urun_id` int(11) NOT NULL,
  `restoran_id` int(11) NOT NULL,
  `calisan_id` int(11) NOT NULL,
  `siparis_tarih` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`siparis_id`),
  KEY `urun_id` (`urun_id`),
  KEY `dukkan_no` (`restoran_id`,`calisan_id`),
  KEY `calisan_id` (`calisan_id`),
  CONSTRAINT `siparis_ibfk_4` FOREIGN KEY (`restoran_id`) REFERENCES `restoran` (`restoran_id`),
  CONSTRAINT `siparis_ibfk_5` FOREIGN KEY (`calisan_id`) REFERENCES `calisan` (`calisan_id`),
  CONSTRAINT `siparis_ibfk_7` FOREIGN KEY (`urun_id`) REFERENCES `urun` (`urun_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `urun`;
CREATE TABLE `urun` (
  `urun_id` int(22) NOT NULL AUTO_INCREMENT,
  `urun_ad` varchar(22) CHARACTER SET latin1 NOT NULL,
  `urun_fiyat` int(22) NOT NULL,
  PRIMARY KEY (`urun_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

INSERT INTO `urun` (`urun_id`, `urun_ad`, `urun_fiyat`) VALUES
(114,	'Ramyon',	85),
(115,	'Gimbab',	65),
(116,	'Bulgogi',	110),
(117,	'Mandu',	75),
(118,	'Jajangmyeon',	110),
(119,	'Chicken Katsu',	99),
(120,	'adw',	123123),
(121,	'a21',	123123),
(122,	'awdawd',	2132),
(123,	'12313',	123123);

-- 2022-12-11 07:04:28
