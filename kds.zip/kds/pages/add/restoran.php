<?php
require_once("config/main.php");
$sehirs = mysqli_query($connection,"SELECT * FROM sehir");
$title = "Restoran Ekle";
?>


<section>
	<div class="row">
		<div class="col-md-12">
	      <!-- general form elements disabled -->
	      <div class="box box-success"> 
	        <div class="box-header">
	          <h3 class="box-title"><?php echo $title; ?></h3>
	        </div><!-- /.box-header -->
	        <div class="box-body">
	          <form role="form" method="post" action="save.php">
	          	<input type="hidden" name="type" value="restoran">
	            <input type="hidden" name="cmd" value="add">
	            <!-- text input -->
	            <div class="form-group">
	              <label>Ad</label>
	              <input type="text" name="restoran_ad" class="form-control" placeholder="Ad" value="" required/>
	            </div>
              <div class="form-group">
                <label>Sehir</label>
                <select name="sehir_id" class="form-control" required>
                  <option value="">Select Option</option>
                  <?php while($sehir = mysqli_fetch_array($sehirs)): ?>
                    <option value="<?php echo $sehir['sehir_id']; ?>"><?php echo $sehir['sehir_ad']; ?></option>
                  <?php endwhile; ?>
                </select>
              </div>
	            <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Save</button>
	            <button type="reset" class="btn btn-warning"> <i class="fa fa-trash"></i> Reset</button>
	            <a href="index.php?page=restoran" class="btn btn-danger"> <i class="fa fa-times"></i> Cancel</a>
	          </form>
	        </div><!-- /.box-body -->
	      </div><!-- /.box -->
	    </div><!--/.col (right) -->
	</div>
</section>