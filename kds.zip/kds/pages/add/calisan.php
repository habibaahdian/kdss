<?php
require_once("config/main.php");
$restorans = mysqli_query($connection,"SELECT * FROM restoran");
$title = "Calisan Ekle";
?>


<section>
	<div class="row">
		<div class="col-md-12">
	      <!-- general form elements disabled -->
	      <div class="box box-success"> 
	        <div class="box-header">
	          <h3 class="box-title"><?php echo $title; ?></h3>
	        </div><!-- /.box-header -->
	        <div class="box-body">
	          <form role="form" method="post" action="save.php">
	          	<input type="hidden" name="type" value="calisan">
	            <input type="hidden" name="cmd" value="add">
	            <!-- text input -->
	            <div class="form-group">
	              <label>Calisan Ad</label>
	              <input type="text" name="calisan_ad" class="form-control" placeholder="Calisan Ad" value="" required />
	            </div>
              <div class="form-group">
	              <label>Soyad</label>
	              <input type="text" name="calisan_soyad" class="form-control" placeholder="Soyad" value="" required/>
	            </div>
              <div class="form-group">
	              <label>Gorev</label>
	              <input type="text" name="gorev" class="form-control" placeholder="Gorev" value="" required/>
	            </div>
              <div class="form-group">
	              <label>Telp</label>
	              <input type="number" name="calisan_telp" class="form-control" placeholder="Telp" value="" required/>
	            </div>
              <div class="form-group">
                <label>Restoran</label>
                <select name="restoran_id" class="form-control" required>
                  <option value="">Select Option</option>
                  <?php while($restoran = mysqli_fetch_array($restorans)): ?>
                    <option value="<?php echo $restoran['restoran_id'];?>"><?php echo $restoran['restoran_ad']; ?></option>
                  <?php endwhile; ?>
                </select>
              </div>
	            <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Save</button>
	            <button type="reset" class="btn btn-warning"> <i class="fa fa-trash"></i> Reset</button>
	            <a href="index.php?page=calisan" class="btn btn-danger"> <i class="fa fa-times"></i> Cancel</a>
	          </form>
	        </div><!-- /.box-body -->
	      </div><!-- /.box -->
	    </div><!--/.col (right) -->
	</div>
</section>