<?php
require_once("config/main.php");
$restorans = mysqli_query($connection,"SELECT * FROM restoran");
$calisans = mysqli_query($connection,"SELECT * FROM calisan");
$uruns = mysqli_query($connection,"SELECT * FROM urun");
$title = "Şipariş Ekle";
?>


<section>
	<div class="row">
		<div class="col-md-12">
	      <!-- general form elements disabled -->
	      <div class="box box-success"> 
	        <div class="box-header">
	          <h3 class="box-title"><?php echo $title; ?></h3>
	        </div><!-- /.box-header -->
	        <div class="box-body">
	          <form role="form" method="post" action="save.php">
	          	<input type="hidden" name="type" value="siparis">
	            <input type="hidden" name="cmd" value="add">
	            <!-- text input -->
	            <div class="form-group">
	              <label>Musteri Ad</label>
	              <input type="text" name="musteri_ad" class="form-control" placeholder="Musteri Ad" value="" required />
	            </div>
              <div class="form-group">
	              <label>Şipariş Toplam</label>
	              <input type="number" name="siparis_toplam" class="form-control" placeholder="Şipariş Toplam" value="" required />
	            </div>
              <div class="form-group">
	              <label>Şipariş Tarih</label>
	              <input type="date" name="siparis_tarih" class="form-control" placeholder="Şipariş Tarih" required />
	            </div>
              <div class="form-group">
                <label>Urun</label>
                <select name="urun_id" class="form-control" required>
                  <option value="">Select Option</option>
                  <?php while($urun = mysqli_fetch_array($uruns)): ?>
                    <option value="<?php echo $urun['urun_id'];?>"><?php echo $urun['urun_ad']; ?></option>
                  <?php endwhile; ?>
                </select>
              </div>
              <div class="form-group">
                <label>Calisan</label>
                <select name="calisan_id" class="form-control" required>
                  <option value="">Select Option</option>
                  <?php while($calisan = mysqli_fetch_array($calisans)): ?>
                    <option value="<?php echo $calisan['calisan_id'];?>"><?php echo $calisan['calisan_ad']; ?></option>
                  <?php endwhile; ?>
                </select>
              </div>
              <div class="form-group">
                <label>Restoran</label>
                <select name="restoran_id" class="form-control" required>
                  <option value="">Select Option</option>
                  <?php while($restoran = mysqli_fetch_array($restorans)): ?>
                    <option value="<?php echo $restoran['restoran_id'];?>"><?php echo $restoran['restoran_ad']; ?></option>
                  <?php endwhile; ?>
                </select>
              </div>
	            <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Save</button>
	            <button type="reset" class="btn btn-warning"> <i class="fa fa-trash"></i> Reset</button>
	            <a href="index.php?page=siparis" class="btn btn-danger"> <i class="fa fa-times"></i> Cancel</a>
	          </form>
	        </div><!-- /.box-body -->
	      </div><!-- /.box -->
	    </div><!--/.col (right) -->
	</div>
</section>