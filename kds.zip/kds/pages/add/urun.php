<section>
	<div class="row">
		<div class="col-md-12">
	      <!-- general form elements disabled -->
	      <div class="box box-success">
	        <div class="box-header">
	          <h3 class="box-title">Urun Ekle</h3>
	        </div><!-- /.box-header -->
	        <div class="box-body">
	          <form role="form" method="post" action="save.php">
	          	<input type="hidden" name="type" value="urun">
	            <input type="hidden" name="cmd" value="add">
	            <!-- text input -->
	            <div class="form-group">
	              <label>Ad</label>
	              <input type="text" name="urun_ad" class="form-control" placeholder="Ad" value="" required/>
	            </div>

              <div class="form-group">
	              <label>Fiyat</label>
	              <input type="number" name="urun_fiyat" class="form-control" placeholder="Fiyat" value="" required/>
	            </div>

	            <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Save</button>
	            <button type="reset" class="btn btn-warning"> <i class="fa fa-trash"></i> Reset</button>
	            <button href="index.php?page=urun" class="btn btn-danger"> <i class="fa fa-times"></i> Cancel</a>
	          </form>
	        </div><!-- /.box-body -->
	      </div><!-- /.box -->
	    </div><!--/.col (right) -->
	</div>
</section>