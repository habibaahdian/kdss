<?php require_once('config/main.php');
$nowYear = date('Y');
$restoran = $_GET['restoran'];
$restoranItem=mysqli_query($connection,"SELECT * FROM restoran where restoran_id = $restoran");
$restoranItem = mysqli_fetch_array($restoranItem);
$monthSiparis = mysqli_query($connection,"SELECT MONTH(siparis_tarih) AS siparis_tarih, SUM(siparis_toplam) AS count FROM siparis WHERE restoran_id = $restoran GROUP BY MONTH(siparis_tarih) ORDER BY siparis_tarih ASC");
$yearSiparis = mysqli_query($connection,"SELECT YEAR(siparis_tarih) AS siparis_tarih, SUM(siparis_toplam) AS count FROM siparis WHERE restoran_id = $restoran  GROUP BY YEAR(siparis_tarih) ORDER BY siparis_tarih ASC");
$urunSiparis = mysqli_query($connection,"SELECT urun.urun_ad, SUM(siparis.siparis_toplam) AS count FROM siparis INNER JOIN urun ON siparis.urun_id = urun.urun_id WHERE siparis.restoran_id = $restoran GROUP BY urun.urun_ad ORDER BY count DESC");
 ?>

<div class="row">
  <div class="col-8" style="margin-left:10px;">
      <?php echo '<div style="font-size:32px;margin-bottom:20px">'.$restoranItem['restoran_ad'].' Restoran</div>'; ?>
  </div>
	<div class="col-md-12">
	  <!-- Bar chart -->
	  <div class="box box-primary">
	    <div class="box-header">
	      <i class="fa fa-bar-chart-o"></i>
	      <h3 class="box-title">Aylık Toplam Satış Tutarları</h3>
	    </div>
	    <div class="box-body">
	      <div id="bar-chart" style="height: 300px;"></div>
	    </div><!-- /.box-body-->
	  </div><!-- /.box -->
	</div>
  <div class="col-md-6">
	  <!-- Bar chart -->
	  <div class="box box-primary">
	    <div class="box-header">
	      <i class="fa fa-bar-chart-o"></i>
	      <h3 class="box-title">Yıllık Toplam Satış Tutarları</h3>
	    </div>
	    <div class="box-body">
	      <div id="bar-chart-year" style="height: 300px;"></div>
	    </div><!-- /.box-body-->
	  </div><!-- /.box -->
	</div>
	<div class="col-md-6">
		<div class="box box-primary">
            <div class="box-header">
              <i class="fa fa-bar-chart-o"></i>
              <h3 class="box-title">Ürün Çok satan</h3>
            </div>
            <div class="box-body">
              <div id="donut-chart" style="height: 300px;"></div>
            </div><!-- /.box-body-->
          </div><!-- /.box -->
        </div><!-- /.col -->
	</div>
</div>
<script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>

<script src="plugins/flot/jquery.flot.min.js" type="text/javascript"></script>
<!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->
<script src="plugins/flot/jquery.flot.resize.min.js" type="text/javascript"></script>
<!-- FLOT PIE PLUGIN - also used to draw donut charts -->
<script src="plugins/flot/jquery.flot.pie.min.js" type="text/javascript"></script>
<!-- FLOT CATEGORIES PLUGIN - Used to draw bar charts -->
<script src="plugins/flot/jquery.flot.categories.min.js" type="text/javascript"></script>

<script type="text/javascript">
  
	$(document).ready(function() {
		/*
         * BAR CHART
         * ---------
         */

        var bar_data_month = {
          data: [
          <?php while($month = mysqli_fetch_array($monthSiparis)) { 
            if($month['siparis_tarih'] == '01') $month['siparis_tarih'] = 'Ocak ('.$month['count'].')';
            if($month['siparis_tarih'] == '02') $month['siparis_tarih'] = 'Şubat ('.$month['count'].')';
            if($month['siparis_tarih'] == '03') $month['siparis_tarih'] = 'Mart ('.$month['count'].')';
            if($month['siparis_tarih'] == '04') $month['siparis_tarih'] = 'Nisan ('.$month['count'].')';
            if($month['siparis_tarih'] == '05') $month['siparis_tarih'] = 'Mayıs ('.$month['count'].')';
            if($month['siparis_tarih'] == '06') $month['siparis_tarih'] = 'Haziran ('.$month['count'].')';
            if($month['siparis_tarih'] == '07') $month['siparis_tarih'] = 'Temmuz ('.$month['count'].')';
            if($month['siparis_tarih'] == '08') $month['siparis_tarih'] = 'Ağustos ('.$month['count'].')';
            if($month['siparis_tarih'] == '09') $month['siparis_tarih'] = 'Eylul ('.$month['count'].')';
            if($month['siparis_tarih'] == '10') $month['siparis_tarih'] = 'Ekim ('.$month['count'].')';
            if($month['siparis_tarih'] == '11') $month['siparis_tarih'] = 'Kasım ('.$month['count'].')';
            if($month['siparis_tarih'] == '12') $month['siparis_tarih'] = 'Aralık ('.$month['count'].')';
            ?>
          	["<?php echo $month['siparis_tarih']; ?>" , <?php echo $month['count']; ?>],
          <?php } ?>
          ],
          color: "#0E9A00",
          hoverable: true,
          points: {
            show: true,
            radius: 5,
            lineWidth: 1.5,
            fill: true,
            fillColor: "#0E9A00"
          },
        };



        $.plot("#bar-chart", [bar_data_month], {
          grid: {
            borderWidth: 1,
            borderColor: "#f3f3f3",
            tickColor: "#F39C12"
          },
          series: {
            bars: {
              show: true,
              barWidth: 0.5,
              align: "center"
            }
          },
          xaxis: {
            mode: "categories",
            tickLength: 0
          }
        });


        var bar_data_year = {
          data: [
          <?php while($year = mysqli_fetch_array($yearSiparis)) { ?>
          	["<?php echo $year['siparis_tarih'].' ('.$year['count'].')'; ?>", <?php echo $year['count']; ?>],
          <?php } ?>
          ],
          color: "#00A3CB"
        };

        $.plot("#bar-chart-year", [bar_data_year], {
          grid: {
            borderWidth: 1,
            borderColor: "#f3f3f3",
            tickColor: "#F39C12"
          },
          series: {
            bars: {
              show: true,
              barWidth: 0.5,
              align: "center",
            },

          },
          xaxis: {
            mode: "categories",
            tickLength: 0
          }
        });
        /* END BAR CHART */

        /*
         * DONUT CHART
         * -----------
         */

        var donutData = [
        <?php while($urun = mysqli_fetch_array($urunSiparis)) { ?>
          {label: "<?php echo $urun['urun_ad']. '('.$urun['count'].')' ; ?>", data: <?php echo $urun['count']; ?>},
        <?php } ?>
        ];
        $.plot("#donut-chart", donutData, {

          series: {
            pie: {
              show: true,
              radius: 1,
              innerRadius: 0.5,
              label: {
                show: true,
                radius: 2 / 3,
                formatter: labelFormatter,
                threshold: 0.1
              }

            }
          },
          legend: {
            show: true,
            labelFormatter: function(label, series) {
              // series is the series object for the label
              return '<div style="font-size:14px; text-align:left; padding:2px; color: #000; font-weight: 600;">' + label + '</div>'
            },

          }
        });
        /*
         * END DONUT CHART
         */
         function labelFormatter(label, series) {
        	return "<div style='font-size:11px; text-align:center; padding:2px; color: #fff; font-weight: 600;'>"
                + label
                + "<br/>"
                + Math.round(series.percent) + "%</div>";
      }
	});	
</script>