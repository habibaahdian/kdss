<?php require_once('config/main.php');
$query=mysqli_query($connection,"select * from siparis s, urun u, restoran r, calisan c where s.urun_id=u.urun_id and s.restoran_id=r.restoran_id and s.calisan_id=c.calisan_id");
 
$title = "Şipariş";
 ?>
<div class="box">
    <div class="box-header">
      <h3 class="box-title"><?php echo $title;?></h3>
    </div>
    <div class="box-body">
    <?php if (isset($_SESSION['username'])): ?>
     <a href="add.php?add=siparis" style="margin-bottom: 10px;" class="btn btn-md btn-primary"> <i class="fa fa-plus"></i> <?php echo $title;?> Ekle </a>
	<?php endif; ?>
		<table width="100%" class="table table-bordered" id="tabel">
		<thead>
			
		  <tr>
		  <th>NO</th>
		  <th>Musteri Ad</th>
		  <th>Şipariş Tarih</th>
		  <th>Şipariş Toplam</th>
		  <th>Urun Ad</th>
			<th>Restoran Ad</th>
			<th>Calisan</th>
			<th>Action</th>
		  </tr>
		</thead>
		<tbody>
			<?php
		  $no=1;
		  while($q=mysqli_fetch_array($query)){
		  ?>
		  <tr>
		    <td><?php echo $no++; ?></td>           
		    <td><?php echo $q['musteri_ad']?></td>
		    <td><?php echo $q['siparis_tarih']?></td>
		    <td><?php echo $q['siparis_toplam']?></td>
		    <td><?php echo $q['urun_ad']?></td>
		    <td><?php echo $q['restoran_ad']?></td>
		    <td><?php echo $q['calisan_ad']?></td>
      <td>
		    	<a class="btn btn-success" href="edit.php?edit=<?php echo $_GET['page']; ?>&siparis_id=<?php echo $q['siparis_id']; ?>">Edit</a>
		    	<a class="btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus data ini?')" href="delete.php?delete=<?php echo $_GET['page']; ?>&siparis_id=<?php echo $q['siparis_id']; ?>">Delete</a>
		    </td>
      </tr>
      <?php } ?>
		</tbody>
		</table>
	</div>
</div>
<script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
<script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
 <script type="text/javascript">
	 $(document).ready(function() {
	 	$('#tabel').dataTable({
	          "bPaginate": true,
	          "bLengthChange": true,
	          "bFilter": true,
	          "bSort": true,
	          "bInfo": true,
	          "bAutoWidth": true,
	    });
	 });
</script>