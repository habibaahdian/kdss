<?php require_once('config/main.php');
$query=mysqli_query($connection,"select * from restoran r,sehir s where r.sehir_id=s.sehir_id");
 
$title = "Restoran";

 ?>
<div class="box">
    <div class="box-header">
      <h3 class="box-title"><?php echo $title;?> </h3>
    </div>
    <div class="box-body">
    <?php if (isset($_SESSION['username'])): ?>
     <a href="add.php?add=restoran" style="margin-bottom: 10px;" class="btn btn-md btn-primary"> <i class="fa fa-plus"></i> <?php echo $title;?> Ekle</a>
	<?php endif; ?>
		<table width="100%" class="table table-bordered" id="tabel">
		<thead>
			
		  <tr>
		  <th>NO</th>
		  <th>Restoran Ad</th>
		  <th>Sehir Ad</th>
			<th>Action</th>
		  </tr>
		</thead>
		<tbody>
			<?php
		  $no=1;
		  while($q=mysqli_fetch_array($query)){
		  ?>
		  <tr>
		    <td><?php echo $no++; ?></td>           
		    <td><?php echo $q['restoran_ad']?></td>
		    <td><?php echo $q['sehir_ad']?></td>
      <td>
      <a class="btn btn-primary" href="?page=restoran_detail&restoran=<?php echo $q['restoran_id']; ?>">Detail</a>
		    	<a class="btn btn-success" href="edit.php?edit=<?php echo $_GET['page']; ?>&restoran_id=<?php echo $q['restoran_id']; ?>">Edit</a>
		    	<a class="btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus data ini?')" href="delete.php?delete=<?php echo $_GET['page']; ?>&restoran_id=<?php echo $q['restoran_id']; ?>">Delete</a>
		    </td>
      </tr>
      <?php } ?>
		</tbody>
		</table>
	</div>
</div>
<script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
<script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
 <script type="text/javascript">
	 $(document).ready(function() {
	 	$('#tabel').dataTable({
	          "bPaginate": true,
	          "bLengthChange": true,
	          "bFilter": true,
	          "bSort": true,
	          "bInfo": true,
	          "bAutoWidth": true
	    });
	 });
</script>