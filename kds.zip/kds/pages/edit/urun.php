<?php require_once('config/main.php');
$query=mysqli_query($connection,"select * from urun where urun_id='$_GET[urun_id]'");
$data = mysqli_fetch_array($query);
 ?>
<section>
	<div class="row">
		<div class="col-md-12">
	      <!-- general form elements disabled -->
	      <div class="box box-success">
	        <div class="box-header">
	          <h3 class="box-title">Urun Düzenle</h3>
	        </div><!-- /.box-header -->
	        <div class="box-body">
	          <form role="form" method="post" action="save.php">
	            <!-- text input -->
	            <input type="hidden" name="urun_id" value="<?php echo $data['urun_id']; ?>">
	            <input type="hidden" name="type" value="urun">
	            <input type="hidden" name="cmd" value="edit">
	            <div class="form-group">
	              <label>Urun</label>
	              <input type="text" name="urun_ad" class="form-control" placeholder="Ad" value="<?php echo $data['urun_ad']; ?>" required/>
	            </div>
	            <!-- textarea -->
	            <div class="form-group">
	              <label>Fiyat</label>
                <input type="text" name="urun_fiyat" class="form-control" placeholder="Ad" value="<?php echo $data['urun_fiyat']; ?>" required/>
	            </div>
	            <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Save</button>
	            <button type="reset" class="btn btn-warning"> <i class="fa fa-backward"></i> Reset</button>
	            <a href="index.php?page=urun" class="btn btn-danger"> <i class="fa fa-times"></i> Cancel</a>
	          </form>
	        </div><!-- /.box-body -->
	      </div><!-- /.box -->
	    </div><!--/.col (right) -->
	</div>
</section>