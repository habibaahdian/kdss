<?php require_once('config/main.php');
$query=mysqli_query($connection,"select * from restoran where restoran_id='$_GET[restoran_id] r,sehir s where r.sehir_id=s.sehir_id'");

$sehirs = mysqli_query($connection,"select * from sehir");
$data = mysqli_fetch_array($query);

$title = "Restoran Düzenle";
 ?>
<section>
	<div class="row">
		<div class="col-md-12">
	      <!-- general form elements disabled -->
	      <div class="box box-success">
	        <div class="box-header">
	          <h3 class="box-title"><?php echo $title; ?></h3>
	        </div><!-- /.box-header -->
	        <div class="box-body">
	          <form role="form" method="post" action="save.php">
	            <!-- text input -->
	            <input type="hidden" name="restoran_id" value="<?php echo $data['restoran_id']; ?>">
	            <input type="hidden" name="type" value="restoran">
	            <input type="hidden" name="cmd" value="edit">
	            <div class="form-group">
	              <label>Restoran</label>
	              <input type="text" name="restoran_ad" class="form-control" placeholder="Ad" value="<?php echo $data['restoran_ad']; ?>" required/>
	            </div>
              <div class="form-group">
                <label>Sehir</label>
                <select name="sehir_id" class="form-control">
                  <?php while($sehir = mysqli_fetch_array($sehirs)) { ?>
                    <option value="<?php echo $sehir['sehir_id']; ?>" <?php if($sehir['sehir_id'] == $data['sehir_id']) { echo "selected"; } ?>><?php echo $sehir['sehir_ad']; ?></option>
                  <?php } ?>
                </select>
              </div>
	            <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Save</button>
	            <button type="reset" class="btn btn-warning"> <i class="fa fa-backward"></i> Reset</button>
	            <a href="index.php?page=restoran" class="btn btn-danger"> <i class="fa fa-times"></i> Cancel</a>
	          </form>
	        </div><!-- /.box-body -->
	      </div><!-- /.box -->
	    </div><!--/.col (right) -->
	</div>
</section>