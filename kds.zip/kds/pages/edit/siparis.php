<?php require_once('config/main.php');
$query=mysqli_query($connection,"select * from siparis where siparis_id='$_GET[siparis_id] s,restoran r,calisan c,urun u where s.restoran_id=r.restoran_id and s.calisan_id=c.calisan_id and s.urun_id=u.urun_id'");

$restorans = mysqli_query($connection,"SELECT * FROM restoran");
$calisans = mysqli_query($connection,"SELECT * FROM calisan");
$uruns = mysqli_query($connection,"SELECT * FROM urun");
$data = mysqli_fetch_array($query);

$title = "Şipariş Düzenle";
 ?>
<section>
	<div class="row">
		<div class="col-md-12">
	      <!-- general form elements disabled -->
	      <div class="box box-success">
	        <div class="box-header">
	          <h3 class="box-title"><?php echo $title; ?></h3>
	        </div><!-- /.box-header -->
	        <div class="box-body">
	          <form role="form" method="post" action="save.php">
	            <!-- text input -->
	            <input type="hidden" name="siparis_id" value="<?php echo $data['siparis_id']; ?>">
	            <input type="hidden" name="type" value="siparis">
	            <input type="hidden" name="cmd" value="edit">
	            <div class="form-group">
	              <label>Muster Ad</label>
	              <input type="text" name="musteri_ad" class="form-control" placeholder="Ad" value="<?php echo $data['musteri_ad']; ?>" required/>
	            </div>
              <div class="form-group">
	              <label>Şipariş Toplam</label>
	              <input type="number" name="siparis_toplam" class="form-control" placeholder="Şipariş Toplam"  value="<?php echo $data['siparis_toplam']; ?>"  required />
	            </div>
              <div class="form-group">
	              <label>Şipariş Tarih</label>
	              <input type="date" name="siparis_tarih" class="form-control" placeholder="Şipariş Tarih" value="<?php echo $data['siparis_tarih']; ?>" required />
	            </div>
              <div class="form-group">
                <label>Urun</label>
                <select name="urun_id" class="form-control">
                  <?php while($urun = mysqli_fetch_array($uruns)) { ?>
                    <option value="<?php echo $urun['urun_id']; ?>" <?php if($urun['urun_id'] == $data['urun_id']) { echo "selected"; } ?>><?php echo $urun['urun_ad']; ?></option>
                  <?php } ?>
                </select>
              </div>
              <div class="form-group">
                <label>Restoran</label>
                <select name="restoran_id" class="form-control">
                  <?php while($restoran = mysqli_fetch_array($restorans)) { ?>
                    <option value="<?php echo $restoran['restoran_id']; ?>" <?php if($restoran['restoran_id'] == $data['restoran_id']) { echo "selected"; } ?>><?php echo $restoran['restoran_ad']; ?></option>
                  <?php } ?>
                </select>
              </div>
              <div class="form-group">
                <label>Calisan</label>
                <select name="calisan_id" class="form-control">
                  <?php while($calisan = mysqli_fetch_array($calisans)) { ?>
                    <option value="<?php echo $calisan['calisan_id']; ?>" <?php if($calisan['calisan_id'] == $data['calisan_id']) { echo "selected"; } ?>><?php echo $calisan['calisan_ad']; ?></option>
                  <?php } ?>
                </select>
              </div>
	            <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Save</button>
	            <button type="reset" class="btn btn-warning"> <i class="fa fa-backward"></i> Reset</button>
	            <a href="index.php?page=siparis" class="btn btn-danger"> <i class="fa fa-times"></i> Cancel</a>
	          </form>
	        </div><!-- /.box-body -->
	      </div><!-- /.box -->
	    </div><!--/.col (right) -->
	</div>
</section>