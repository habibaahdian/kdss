<?php require_once('config/main.php');
$query=mysqli_query($connection,"select * from calisan where calisan_id='$_GET[calisan_id] c,restoran r where c.restoran_id=r.restoran_id'");

$restorans = mysqli_query($connection,"select * from restoran");
$data = mysqli_fetch_array($query);

$title = "Calisan Düzenle";
 ?>
<section>
	<div class="row">
		<div class="col-md-12">
	      <!-- general form elements disabled -->
	      <div class="box box-success">
	        <div class="box-header">
	          <h3 class="box-title"><?php echo $title; ?></h3>
	        </div><!-- /.box-header -->
	        <div class="box-body">
	          <form role="form" method="post" action="save.php">
	            <!-- text input -->
	            <input type="hidden" name="calisan_id" value="<?php echo $data['calisan_id']; ?>">
	            <input type="hidden" name="type" value="calisan">
	            <input type="hidden" name="cmd" value="edit">
	            <div class="form-group">
	              <label>Calisan Ad</label>
	              <input type="text" name="calisan_ad" class="form-control" placeholder="Ad" value="<?php echo $data['calisan_ad']; ?>" required/>
	            </div>
              <div class="form-group">
	              <label>Soyad</label>
	              <input type="text" name="calisan_soyad" class="form-control" placeholder="Soyad" value="<?php echo $data['calisan_soyad']; ?>" required/>
	            </div>
              <div class="form-group">
	              <label>Gorev</label>
	              <input type="text" name="gorev" class="form-control" placeholder="Gorev" value="<?php echo $data['gorev']; ?>" required/>
	            </div>
              <div class="form-group">
	              <label>Telp</label>
	              <input type="number" name="calisan_telp" class="form-control" placeholder="Telp" value="<?php echo $data['calisan_telp']; ?>" required/>
	            </div>
              <div class="form-group">
                <label>Restoran</label>
                <select name="restoran_id" class="form-control">
                  <?php while($restoran = mysqli_fetch_array($restorans)) { ?>
                    <option value="<?php echo $restoran['restoran_id']; ?>" <?php if($restoran['restoran_id'] == $data['restoran_id']) { echo "selected"; } ?>><?php echo $restoran['restoran_ad']; ?></option>
                  <?php } ?>
                </select>
              </div>
	            <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Save</button>
	            <button type="reset" class="btn btn-warning"> <i class="fa fa-backward"></i> Reset</button>
	            <a href="index.php?page=calisan" class="btn btn-danger"> <i class="fa fa-times"></i> Cancel</a>
	          </form>
	        </div><!-- /.box-body -->
	      </div><!-- /.box -->
	    </div><!--/.col (right) -->
	</div>
</section>