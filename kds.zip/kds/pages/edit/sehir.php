<?php require_once('config/main.php');
$query=mysqli_query($connection,"select * from sehir where sehir_id='$_GET[sehir_id]'");
$data = mysqli_fetch_array($query);
 ?>
<section>
	<div class="row">
		<div class="col-md-12">
	      <!-- general form elements disabled -->
	      <div class="box box-success">
	        <div class="box-header">
	          <h3 class="box-title">Sehir Düzenle</h3>
	        </div><!-- /.box-header -->
	        <div class="box-body">
	          <form role="form" method="post" action="save.php">
	            <!-- text input -->
	            <input type="hidden" name="sehir_id" value="<?php echo $data['sehir_id']; ?>">
	            <input type="hidden" name="type" value="sehir">
	            <input type="hidden" name="cmd" value="edit">
	            <div class="form-group">
	              <label>Sehir</label>
	              <input type="text" name="sehir_ad" class="form-control" placeholder="Ad" value="<?php echo $data['sehir_ad']; ?>" required/>
	            </div>
	            <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Save</button>
	            <button type="reset" class="btn btn-warning"> <i class="fa fa-backward"></i> Reset</button>
	            <a href="index.php?page=sehir" class="btn btn-danger"> <i class="fa fa-times"></i> Cancel</a>
	          </form>
	        </div><!-- /.box-body -->
	      </div><!-- /.box -->
	    </div><!--/.col (right) -->
	</div>
</section>