<?php require_once('config/main.php');
$query=mysqli_query($connection,"select * from urun");
 ?>
<div class="box">
    <div class="box-header">
      <h3 class="box-title">Urun</h3>
    </div><!-- /.box-header -->
    <div class="box-body">
    <?php if (isset($_SESSION['username'])): ?>
     <a href="add.php?add=urun" style="margin-bottom: 10px;" class="btn btn-md btn-primary"> <i class="fa fa-plus"></i>Urun Ekle</a>
	<?php endif; ?>
		<table width="100%" class="table table-bordered" id="tabel">
		<thead>
			
		  <tr>
		  <th>NO</th>
		  <th>Urun Ad</th>
			<th>Fiyat</th>
			<th>Action</th>
		  </tr>
		</thead>
		<tbody>
			<?php
		  $no=1;
		  while($q=mysqli_fetch_array($query)){
		  ?>
		  <tr>
		    <td><?php echo $no++; ?></td>           
		    <td><?php echo $q['urun_ad']?></td>
			<td><?php echo $q['urun_fiyat']?></td>
      <td>
		    	<a class="btn btn-success" href="edit.php?edit=<?php echo $_GET['page']; ?>&urun_id=<?php echo $q['urun_id']; ?>">Edit</a>
		    	<a class="btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus data ini?')" href="delete.php?delete=<?php echo $_GET['page']; ?>&urun_id=<?php echo $q['urun_id']; ?>">Delete</a>
		    </td>
      </tr>
      <?php } ?>
		</tbody>
		</table>
	</div>
</div>
<script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
<script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
 <script type="text/javascript">
	 $(document).ready(function() {
	 	$('#tabel').dataTable({
	          "bPaginate": true,
	          "bLengthChange": true,
	          "bFilter": true,
	          "bSort": true,
	          "bInfo": true,
	          "bAutoWidth": true
	    });
	 });
</script>