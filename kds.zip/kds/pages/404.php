<div class="error-page">
  <h2 class="headline text-yellow"> 404</h2>
  <div class="error-content">
    <h3><i class="fa fa-warning text-yellow"></i> Oops! Halaman yang anda maksud tidak ditemukan.</h3>
    <p>
      Kami tidak dapat menemukan halaman yang anda maksud
     Silakan cek kembali apakah url yang anda masukkan benar :)
    </p>
  </div><!-- /.error-content -->
</div><!-- /.error-page -->