<?php
session_start();
session_destroy();
echo "<script>alert('You Have Signed Out From Login As Admin'); window.location = 'index.php'</script>";
?>