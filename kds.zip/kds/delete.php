<?php 
if (isset($_GET['delete'])) {
	require "config/main.php";
	switch ($_GET['delete']) {
		case 'urun':
			mysqli_query($connection,"DELETE FROM urun WHERE urun_id=".$_GET['urun_id']);
			header('Location:index.php?page='.$_GET['delete']);
			break;
    case 'sehir':
      mysqli_query($connection,"DELETE FROM sehir WHERE sehir_id=".$_GET['sehir_id']);
      header('Location:index.php?page='.$_GET['delete']);
      break;
    case 'restoran':
      mysqli_query($connection,"DELETE FROM restoran WHERE restoran_id=".$_GET['restoran_id']);
      header('Location:index.php?page='.$_GET['delete']);
      break;
		case 'admin':
			mysqli_query($connection,"DELETE FROM admin WHERE id=".$_GET['id']);
			header('Location:index.php?page='.$_GET['delete']);
			break;
    case 'calisan':
      mysqli_query($connection,"DELETE FROM calisan WHERE calisan_id=".$_GET['calisan_id']);
      header('Location:index.php?page='.$_GET['delete']);
      break;
    case 'siparis':
      mysqli_query($connection,"DELETE FROM siparis WHERE siparis_id=".$_GET['siparis_id']);
      header('Location:index.php?page='.$_GET['delete']);
      break;
		default:
			require_once("pages/404.php");
			break;
	}
}
else {
	require_once("pages/home.php");
}

 ?>