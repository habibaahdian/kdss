<?php 

require "config/main.php";
$type = trim($_POST['type']);
$cmd = trim($_POST['cmd']);

switch ($type) {
	case 'urun':
		if ($cmd=="add") {
			mysqli_query($connection,"INSERT INTO urun(urun_ad,urun_fiyat)
			VALUES('$_POST[urun_ad]',
					'$_POST[urun_fiyat]')");
		}
		elseif($cmd=="edit") {
			mysqli_query($connection,"UPDATE urun SET urun_ad='$_POST[urun_ad]',
				urun_fiyat='$_POST[urun_fiyat]'
				WHERE urun_id='$_POST[urun_id]'");
		}
		else {
			die(); 
		}
		header('Location:index.php?page=urun');
		break;
  case 'sehir':
    if ($cmd=="add") {
      mysqli_query($connection,"INSERT INTO sehir(sehir_ad)
      VALUES('$_POST[sehir_ad]')");
    }
    elseif($cmd=="edit") {
      mysqli_query($connection,"UPDATE sehir SET sehir_ad='$_POST[sehir_ad]'
        WHERE sehir_id='$_POST[sehir_id]'");
    }
    else {
      die();
    }
    header('Location:index.php?page=sehir');
    break;
  case 'restoran':
    if ($cmd=="add") {
      mysqli_query($connection,"INSERT INTO restoran(restoran_ad,sehir_id)
      VALUES('$_POST[restoran_ad]',
          '$_POST[sehir_id]')");
    }
    elseif($cmd=="edit") {
      mysqli_query($connection,"UPDATE restoran SET restoran_ad='$_POST[restoran_ad]', sehir_id='$_POST[sehir_id]'
        WHERE restoran_id='$_POST[restoran_id]'");
    }
    else {
      die();
    }
    header('Location:index.php?page=restoran');
    break;
  case 'calisan':
    if ($cmd=="add") {
      mysqli_query($connection,"INSERT INTO calisan(calisan_ad,calisan_soyad,gorev,calisan_telp,restoran_id)
      VALUES('$_POST[calisan_ad]',
          '$_POST[calisan_soyad]',
          '$_POST[gorev]',
          '$_POST[calisan_telp]',
          '$_POST[restoran_id]')");
    }

    elseif($cmd=="edit") {
      mysqli_query($connection,"UPDATE calisan SET calisan_ad='$_POST[calisan_ad]',calisan_soyad='$_POST[calisan_soyad]',gorev='$_POST[gorev]',calisan_telp='$_POST[calisan_telp]', restoran_id='$_POST[restoran_id]'
        WHERE calisan_id='$_POST[calisan_id]'");
    }
    else {
      die();
    }
    header('Location:index.php?page=calisan');
    break;
  case 'siparis':
    if ($cmd=="add") {
      mysqli_query($connection,"INSERT INTO siparis(musteri_ad,urun_id,restoran_id,calisan_id,siparis_tarih,siparis_toplam)
      VALUES('$_POST[musteri_ad]',
          '$_POST[urun_id]',
          '$_POST[restoran_id]',
          '$_POST[calisan_id]','$_POST[siparis_tarih]','$_POST[siparis_toplam]')");
    }
    
    elseif($cmd=="edit") {
      mysqli_query($connection,"UPDATE siparis SET musteri_ad='$_POST[musteri_ad]',urun_id='$_POST[urun_id]', restoran_id='$_POST[restoran_id]', calisan_id='$_POST[calisan_id]',siparis_tarih='$_POST[siparis_tarih]',siparis_toplam='$_POST[siparis_toplam]'
        WHERE siparis_id='$_POST[siparis_id]'");
    }
    else {
      die();
    }
    header('Location:index.php?page=siparis');
    break;
	case 'admin':
		if ($cmd=="add") {
			mysqli_query($connection,"INSERT INTO admin(name,username,password)
			VALUES('$_POST[name]',
			'$_POST[username]',
			'$_POST[password]')");
		}
		elseif($cmd=="edit") {
			mysqli_query($connection,"UPDATE admin SET name='$_POST[name]',
				username='$_POST[username]',
				password='$_POST[password]'
				WHERE id=".$_POST['id']);
			
		}
		else {
			die(); //jika bukan add atau edit, lalu apa ? die aja lah :p
		}
		header('Location:index.php?page=admin');
		break;
	
	default:
		require_once("pages/404.php");
		break;
}

 ?>