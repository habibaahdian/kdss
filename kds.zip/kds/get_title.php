<?php 

if (isset($_GET['page'])) {
  $page = $_GET['page'];
	echo $title;
}
else {
	echo "Halaman Utama";
}

 ?>