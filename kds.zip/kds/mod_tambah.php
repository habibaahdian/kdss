<?php 

if (isset($_GET['add'])) {
	$path = "pages/add/".$_GET['add'].".php";
	if (file_exists($path)) {
		require_once($path);
	}
	else {
		require_once("pages/404.php");
	}
}
else {
	require_once("pages/home.php");
}

 ?>