<?php
$server = "localhost"; //name server
$username = "root"; // username 
$password = ""; //  standarnya kosong
$database = "kds2"; // buat name database harus sama 

// Koneksi dan memilih database di server
$connection = mysqli_connect($server,$username,$password,$database);
if(!$connection){
  die("connection error");
}
?>
