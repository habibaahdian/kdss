<?php require_once('config/main.php');
$calisans = mysqli_query($connection,"select * from calisan");
$restorans=mysqli_query($connection,"select * from restoran");
$siparis=mysqli_query($connection,"select * from siparis");
$uruns = mysqli_query($connection,"select * from urun");
 ?>
<div class="row">
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-aqua">
        <div class="inner">
          <h3><?php echo mysqli_num_rows($calisans); ?></h3>
          <p>Calisan</p>
        </div>
        <div class="icon">
          <i class="fa fa-user"></i>
        </div>
        <a href="./?page=calisan" class="small-box-footer">Daha Fazla <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-green">
        <div class="inner">
          <h3><?php echo mysqli_num_rows($siparis); ?></h3>
          <p>Şipariş</p>
        </div>
        <div class="icon">
          <i class="fa fa-money"></i>
        </div>
        <a href="./?page=siparis" class="small-box-footer">Daha Fazla <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-yellow">
        <div class="inner">
          <h3><?php echo mysqli_num_rows($restorans); ?></h3>
          <p>Restoran</p>
        </div>
        <div class="icon">
          <i class="fa fa-group"></i>
        </div>
        <a href="./?page=restoran" class="small-box-footer">Daha Fazla <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-red">
        <div class="inner">
          <h3><?php echo mysqli_num_rows($uruns); ?></h3>
          <p>Urun</p>
        </div>
        <div class="icon">
          <i class="fa fa-file"></i>
        </div>
        <a href="./?page=urun" class="small-box-footer">Daha Fazla <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
  </div><!-- /.row -->
  <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>